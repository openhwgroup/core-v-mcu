.. Edalize documentation master file, created by
   sphinx-quickstart on Thu Jan 17 08:54:32 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Edalize's documentation!
===================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   edam/api
   source/modules
   source/tests


Indices and tables
==================


* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
