.. _ug_build_system_flags:

Flags: constraints in dependencies
==================================

.. todo::

   Document flags.
