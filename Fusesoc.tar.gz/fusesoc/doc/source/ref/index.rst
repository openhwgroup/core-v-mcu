########################
FuseSoC Reference Manual
########################

.. toctree::
   :maxdepth: 2
   :caption: Contents

   capi2.rst
   migrations.rst
   glossary.rst
