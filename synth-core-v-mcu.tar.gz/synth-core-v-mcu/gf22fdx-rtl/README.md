# core-v-mcu2-rtl-modules-gd22fdx
Private core-v-mcu2 repo for gf22fdx specific rtl
